﻿using System;

namespace Productivity_BO
{
    public class clsEntity_Master_Employee
    {
        public string EmployeeCode { get; set; }
        public string EmployeeName { get; set; }
        public string CustomerName { get; set; }
        public string ProjectName { get; set; }
        public string DepartmentName { get; set; }
        public string DepartmentCode { get; set; }
        public string MobileNo { get; set; }
        public string SupervisorEmployeeCode { get; set; }
        public string CustomerCode { get; set; }
        public string ProjectCode { get; set; }
        public string CreatedDateTime { get; set; }
        public string UpdatedDateTime { get; set; }
        public bool Status { get; set; }
    }
}

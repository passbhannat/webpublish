﻿using System;

namespace Productivity_BO
{
    public class clsEntity_Master_Task
    {
        public string TaskAllocationID { get; set; }
        public string TaskUpdationID { get; set; }
        public string EmployeeCode { get; set; }    
        public string EmployeeName { get; set; }    
        public string ProjectName { get; set; }    
        public string ActivityName { get; set; }    
        public string ProjectCode { get; set; }    
        public string ActivityCode { get; set; }
        public string TransactionCompleted { get; set; }
        public string TaskDate { get; set; }
        public string TimeIn { get; set; }
        public string TimeOut { get; set; }
        public string CustomerCode { get; set; }
        public string CustomerName { get; set; }
        public string HourlyTarget { get; set; }
        public string DailyTarget { get; set; }
        public string CreatedDateTime { get; set; }
        public string UpdatedDateTime { get; set; }
        public string Status { get; set; }

    }
}   

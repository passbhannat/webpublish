﻿using System;

namespace Productivity_BO
{
    public class clsEntity_Master_Activity
    {
        public string ActivityCode { get; set; }
        public string ActivityName { get; set; }    
        public string ProjectName { get; set; }    
        public string CustomerName { get; set; }    
        public string ProjectCode { get; set; }    
        public string CustomerCode { get; set; }
        public string CreatedDateTime { get; set; }
        public string UpdatedDateTime { get; set; }
        public bool Status { get; set; }
    }
}   

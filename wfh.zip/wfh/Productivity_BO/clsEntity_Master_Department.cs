﻿using System;

namespace Productivity_BO
{
    public class clsEntity_Master_Department
    {
        public string DepartmentCode { get; set; }
        public string DepartmentName { get; set; }
        public string CreatedDateTime { get; set; }
        public string UpdatedDateTime { get; set; }
        public bool Status { get; set; }
    }
}   

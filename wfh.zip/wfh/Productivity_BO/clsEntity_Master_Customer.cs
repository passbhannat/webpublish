﻿using System;

namespace Productivity_BO
{
    public class clsEntity_Master_Customer
    {
        public string CustomerCode { get; set; }
        public string CustomerName { get; set; }
        public string CreatedDateTime { get; set; }
        public string UpdatedDateTime { get; set; }
        public bool Status { get; set; }
    }
}   

﻿using System;

namespace Productivity_BO
{
    public class clsEntity_Master_Attendance
    {
        public string AttendanceId { get; set; }
        public string EmployeeCode { get; set; }
        public string PunchDate { get; set; }
        public string PunchIn { get; set; }
        public string PunchOut { get; set; }
    }
}   

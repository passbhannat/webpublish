﻿using Productivity_BO;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Configuration;

namespace Productivity_DAL
{
    public class clsDataAccess
    {
        string SQLConnectionString;

        SqlConnection con;

        public clsDataAccess()
        {
            SQLConnectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog=Productivity;uid=sa;password=Mumbai123";
            //SQLConnectionString = ConfigurationManager.ConnectionStrings["ProductivityConnectionString"].ToString();
        }

        # region Database Method

        public SqlConnection OpenConnection()
        {
            try
            {
                con = new SqlConnection();
                con.ConnectionString = SQLConnectionString;
            }
            catch (Exception ex)
            {

            }
            return con;
        }

        public T BindDataTable_ToClass<T>(DataTable dt)
        {
            // Create object
            var ob = Activator.CreateInstance<T>();

            try
            {
                DataRow dr = dt.Rows[0];

                // Get all columns' name
                List<string> columns = new List<string>();
                foreach (DataColumn dc in dt.Columns)
                {
                    columns.Add(dc.ColumnName);
                }


                // Get all fields
                var fields = typeof(T).GetFields();
                foreach (var fieldInfo in fields)
                {
                    if (columns.Contains(fieldInfo.Name))
                    {
                        // Fill the data into the field
                        fieldInfo.SetValue(ob, dr[fieldInfo.Name]);
                    }
                }

                // Get all properties
                var properties = typeof(T).GetProperties();
                foreach (var propertyInfo in properties)
                {
                    if (columns.Contains(propertyInfo.Name))
                    {
                        // Fill the data into the property
                        propertyInfo.SetValue(ob, dr[propertyInfo.Name], null);
                    }
                }
            }
            catch
            {

            }
            return ob;
        }

        public DataSet FillDataset(string Query, SqlConnection conn)
        {
            DataSet ods = new DataSet();
            try
            {
                SqlCommand cmd = new SqlCommand(Query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ods);
                return ods;
            }
            catch(Exception ex)
            {
            }
            finally
            {
                if (con != null || con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return ods;

        }

        public string InsertUpdateDelete_Record(string Query, SqlConnection conn)
        {
            string Value = string.Empty;
            SqlCommand cmd = null;
            try
            {
                cmd = new SqlCommand(Query, conn);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
            }
            finally
            {
                cmd.Dispose();
                conn.Close();
            }
            return Value;

        }

        public string GetRecord(string Query, SqlConnection conn)
        {
            string Value = string.Empty;
            SqlDataReader dr;
            SqlCommand cmd = null;
            try
            {
                cmd = new SqlCommand(Query, conn);
                conn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    Value = dr[0].ToString();
                }
                dr.Close();

            }
            catch(Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                conn.Close();
            }
            return Value;

        }

        public DataSet FillDataset_Params(string commandText, SqlConnection conn, params SqlParameter[] parameters)
        {

            DataSet ods = new DataSet();
            try
            {

                SqlCommand cmd = new SqlCommand();
                cmd.Parameters.AddRange(parameters);
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = commandText;
                cmd.Connection = conn;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ods);
                return ods;
            }
            catch (Exception ex)
            {
            }
            finally
            {
            }
            return ods;
        }

        public DataSet FillDatasetSP_Params(string commandText, SqlConnection conn, params SqlParameter[] parameters)
        {
            DataSet ods = new DataSet();
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Parameters.AddRange(parameters);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = commandText;
                cmd.Connection = conn;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ods);
                return ods;
            }
            catch (Exception ex)
            {
            }
            finally
            {
            }
            return ods;
        }

        public string ScalarValueSP_Params(string commandText, SqlConnection conn, params SqlParameter[] parameters)
        {
            string resultCode = null;
            SqlCommand cmd = null;

            try
            {
                cmd = new SqlCommand();
                cmd.Parameters.AddRange(parameters);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = commandText;
                cmd.Connection = conn;
                conn.Open();
                resultCode = Convert.ToString(cmd.ExecuteScalar());

                return resultCode;
            }
            catch (Exception ex)
            {
            }
            finally
            {
                cmd.Dispose();
                conn.Close();
            }

            return resultCode;
        }

        public List<T> ConvertTo<T>(DataTable datatable) where T : new()
        {
            List<T> Temp = new List<T>();
            try
            {
                List<string> columnsNames = new List<string>();
                foreach (DataColumn DataColumn in datatable.Columns)
                    columnsNames.Add(DataColumn.ColumnName);
                Temp = datatable.AsEnumerable().ToList().ConvertAll<T>(row => getObject<T>(row, columnsNames));
                return Temp;
            }
            catch
            {
                return Temp;
            }
        }

        private T getObject<T>(DataRow row, List<string> columnsName) where T : new()
        {
            T obj = new T();
            try
            {
                string columnname = "";
                string value = "";
                PropertyInfo[] Properties;
                Properties = typeof(T).GetProperties();
                foreach (PropertyInfo objProperty in Properties)
                {
                    columnname = columnsName.Find(name => name.ToLower() == objProperty.Name.ToLower());
                    if (!string.IsNullOrEmpty(columnname))
                    {
                        value = row[columnname].ToString();
                        if (!string.IsNullOrEmpty(value))
                        {
                            if (Nullable.GetUnderlyingType(objProperty.PropertyType) != null)
                            {
                                value = row[columnname].ToString().Replace("$", "").Replace(",", "");
                                objProperty.SetValue(obj, Convert.ChangeType(value, Type.GetType(Nullable.GetUnderlyingType(objProperty.PropertyType).ToString())), null);
                            }
                            else
                            {
                                value = row[columnname].ToString();
                                objProperty.SetValue(obj, Convert.ChangeType(value, Type.GetType(objProperty.PropertyType.ToString())), null);
                            }
                        }
                    }
                }
                return obj;
            }
            catch
            {
                return obj;
            }
        }

        #endregion
    }
}



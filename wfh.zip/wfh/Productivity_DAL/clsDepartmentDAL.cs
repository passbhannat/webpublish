﻿using System;
using Productivity_BO;
using System.Text;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Productivity_DAL
{
    public class clsDepartmentDAL : clsDataAccess
    {
        SqlDataAdapter adp = null;
        SqlConnection con = null; 
        DataSet vDs = null;
        SqlCommandBuilder vCmBld = null;

        public List<clsEntity_Master_Department> Get_DepartmentMaster(string DepartmentCode)
        {
            List<clsEntity_Master_Department> objList = null;
         
            try
            {
                StringBuilder query = new StringBuilder();

                query.Append(" SELECT [DepartmentCode], [DepartmentName] FROM Master_Department WHERE STATUS = 1 ");

                if (!string.IsNullOrEmpty(DepartmentCode))
                {
                    query.Append(" AND DepartmentCode='" + DepartmentCode + "' ");
                }

                using (DataTable datatable = FillDataset(query.ToString(), OpenConnection()).Tables[0])
                {
                    objList = ConvertTo<clsEntity_Master_Department>(datatable);
                }
            }
            catch (Exception ex)
            {

            }

            return objList;
        }

        public bool SaveUpdate_DepartmentMaster(clsEntity_Master_Department objEntity, bool isSave, out string _strResult)
        {
            _strResult = string.Empty;
            adp = new SqlDataAdapter();
            con = new SqlConnection();
            vDs = new DataSet();
            vCmBld = null;

            try
            {
                string tableName = "Master_Department";
                string code = "0";

                if (isSave == false)
                {
                    code = objEntity.DepartmentCode.ToString();
                }

                DataRow vdr;
                con = OpenConnection();
                adp.SelectCommand = new SqlCommand();
                vCmBld = new SqlCommandBuilder(adp);
                adp.SelectCommand.Connection = con;
                adp.SelectCommand.CommandText = "SELECT * FROM " + tableName + " WHERE DepartmentCode = '"+ code + "'";
                adp.Fill(vDs, tableName);

                if (isSave)
                {
                    vdr = vDs.Tables[tableName].NewRow();

                    vdr["DepartmentCode"] = objEntity.DepartmentCode;
                    vdr["DepartmentName"] = objEntity.DepartmentName;
                    vdr["CreatedDateTime"] = DateTime.Now.ToString();
                    vdr["Status"] = true;

                    vDs.Tables[tableName].Rows.Add(vdr);
                }
                else
                {
                    vdr = vDs.Tables[tableName].Rows[0];

                    vdr["DepartmentName"] = objEntity.DepartmentName;
                    vdr["UpdatedDateTime"] = DateTime.Now.ToString();
                }
                               
                adp.Update(vDs, tableName);
            }
            catch (Exception ex)
            {
                _strResult = ex.Message;
                return false;
            }
            finally
            {
                con.Close();
                vCmBld.Dispose();
                vDs.Dispose();
                adp.Dispose();
            }

            return true;
        }

        public bool DeleteDepartment(string departmentCode)
        {
            try
            {
                string tableName = "Master_Department";
                string query = "UPDATE " + tableName + " SET STATUS = 0 WHERE DepartmentCode ='" + departmentCode + "' ";
                InsertUpdateDelete_Record(query.ToString(), OpenConnection());
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}

﻿using System;
using Productivity_BO;
using System.Text;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Productivity_DAL
{
    public class clsEmployeeDAL : clsDataAccess
    {
        SqlDataAdapter adp = null;
        SqlConnection con = null; 
        DataSet vDs = null;
        SqlCommandBuilder vCmBld = null;

        public List<clsEntity_Master_Employee> Get_EmployeeMaster(string EmployeeCode)
        {
            List<clsEntity_Master_Employee> objList = null;

            try
            {
                StringBuilder query = new StringBuilder();

                query.Append(" SELECT T1.EmployeeCode, T1.EmployeeName, T1.CustomerCode, T1.ProjectCode,T1.DepartmentCode,T1.MobileNo, T1.SupervisorEmployeeCode, T2.CustomerName, T3.ProjectName, T4.DepartmentName ");
                query.Append(" FROM Master_Employee T1 ");
                query.Append(" LEFT JOIN Master_Customer T2 ");
                query.Append(" ON T1.CustomerCode = T2.CustomerCode ");
                query.Append(" LEFT JOIN Master_Project T3 ");
                query.Append(" ON T1.ProjectCode = T3.ProjectCode ");
                query.Append(" LEFT JOIN Master_Department T4 ");
                query.Append(" ON T1.DepartmentCode = T4.DepartmentCode ");
                query.Append(" WHERE T1.STATUS = 1 ");

                if (!string.IsNullOrEmpty(EmployeeCode))
                {
                    query.Append(" AND T1.EmployeeCode='" + EmployeeCode + "' ");
                }

                using (DataTable datatable = FillDataset(query.ToString(), OpenConnection()).Tables[0])
                {
                    objList = ConvertTo<clsEntity_Master_Employee>(datatable);
                }
            }
            catch (Exception ex)
            {

            }

            return objList;
        }

        public bool SaveUpdate_EmployeeMaster(clsEntity_Master_Employee objEntity, bool isSave, out string _strResult)
        {
            _strResult = string.Empty;
            adp = new SqlDataAdapter();
            con = new SqlConnection();
            vDs = new DataSet();
            vCmBld = null;

            try
            {
                string tableName = "Master_Employee";
                string code = "0";

                if (isSave == false)
                {
                    code = objEntity.EmployeeCode.ToString();
                }

                DataRow vdr;
                con = OpenConnection();
                adp.SelectCommand = new SqlCommand();
                vCmBld = new SqlCommandBuilder(adp);
                adp.SelectCommand.Connection = con;
                adp.SelectCommand.CommandText = "SELECT * FROM " + tableName + " WHERE EmployeeCode = '" + code + "'";
                adp.Fill(vDs, tableName);

                if (isSave)
                {
                    vdr = vDs.Tables[tableName].NewRow();

                    vdr["EmployeeCode"] = objEntity.EmployeeCode;
                    vdr["EmployeeName"] = objEntity.EmployeeName;
                    vdr["DepartmentCode"] = objEntity.DepartmentCode;
                    vdr["MobileNo"] = objEntity.MobileNo;
                    vdr["SupervisorEmployeeCode"] = objEntity.SupervisorEmployeeCode;
                    vdr["CustomerCode"] = objEntity.CustomerCode;
                    vdr["ProjectCode"] = objEntity.ProjectCode;
                    vdr["CreatedDateTime"] = DateTime.Now.ToString();
                    vdr["Status"] = true;

                    vDs.Tables[tableName].Rows.Add(vdr);
                }
                else
                {
                    vdr = vDs.Tables[tableName].Rows[0];

                    vdr["EmployeeName"] = objEntity.EmployeeName;
                    vdr["DepartmentCode"] = objEntity.DepartmentCode;
                    vdr["MobileNo"] = objEntity.MobileNo;
                    vdr["SupervisorEmployeeCode"] = objEntity.SupervisorEmployeeCode;
                    vdr["CustomerCode"] = objEntity.CustomerCode;
                    vdr["ProjectCode"] = objEntity.ProjectCode;
                    vdr["UpdatedDateTime"] = DateTime.Now.ToString();
                }

                adp.Update(vDs, tableName);
            }
            catch (Exception ex)
            {
                _strResult = ex.Message;
                return false;
            }
            finally
            {
                con.Close();
                vCmBld.Dispose();
                vDs.Dispose();
                adp.Dispose();
            }

            return true;
        }

        public List<clsEntity_Master_Employee> Get_EmployeeList()
        {
            List<clsEntity_Master_Employee> objList = null;

            try
            {
                StringBuilder query = new StringBuilder();

                query.Append(" SELECT EmployeeCode, EmployeeName");
                query.Append(" FROM Master_Employee ");
                query.Append(" WHERE Status = 1 ");

                using (DataTable datatable = FillDataset(query.ToString(), OpenConnection()).Tables[0])
                {
                    objList = ConvertTo<clsEntity_Master_Employee>(datatable);
                }
            }
            catch (Exception ex)
            {

            }

            return objList;
        }

        public bool DeleteEmployee(string employeeCode)
        {
            try
            {
                string tableName = "Master_Employee";
                string query = "UPDATE " + tableName + " SET STATUS = 0 WHERE EmployeeCode ='" + employeeCode + "' ";
                InsertUpdateDelete_Record(query.ToString(), OpenConnection());
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}

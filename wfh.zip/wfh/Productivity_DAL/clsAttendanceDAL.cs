﻿using System;
using Productivity_BO;
using System.Text;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Productivity_DAL
{
    public class clsAttendanceDAL : clsDataAccess
    {
        SqlDataAdapter adp = null;
        SqlConnection con = null;
        DataSet vDs = null;
        SqlCommandBuilder vCmBld = null;

        public List<clsEntity_Master_Attendance> Get_AttendanceList(string employeeCode)
        {
            List<clsEntity_Master_Attendance> objList = null;

            try
            {
                StringBuilder query = new StringBuilder();
                query.Append( " SELECT AttendanceId, Convert(varchar, PunchDate, 104) [PunchDate], PunchIn, PunchOut ");
                query.Append( " FROM Transaction_Attendance ");
                query.Append( " WHERE EmployeeCode = '" + employeeCode + "' ");
                query.Append( " ORDER BY AttendanceID desc ");

                using (DataTable datatable = FillDataset(query.ToString(), OpenConnection()).Tables[0])
                {
                    objList = ConvertTo<clsEntity_Master_Attendance>(datatable);
                }
            }
            catch (Exception ex)
            {

            }

            return objList;
        }

        public List<clsEntity_Master_Attendance> Get_AttendanceByEmployeeDate(string employeeCode)
        {
            List<clsEntity_Master_Attendance> objList = null;

            try
            {
                StringBuilder query = new StringBuilder();
                query.Append(" SELECT * FROM Transaction_Attendance ");
                query.Append(" WHERE EmployeeCode = '" + employeeCode + "' and convert(varchar, PunchDate, 105) ='" + DateTime.Now.ToShortDateString()  +"' and PunchIn IS NOT NULL");

                using (DataTable datatable = FillDataset(query.ToString(), OpenConnection()).Tables[0])
                {
                    objList = ConvertTo<clsEntity_Master_Attendance>(datatable);
                }
            }
            catch (Exception ex)
            {

            }

            return objList;
        }

        public bool PunchIn(clsEntity_Master_Attendance objEntity, bool isSave, out string _strResult)
        {
            _strResult = string.Empty;
            adp = new SqlDataAdapter();
            con = new SqlConnection();
            vDs = new DataSet();
            vCmBld = null;

            try
            {
                string tableName = "Transaction_Attendance";
                string code = "0";

                if (isSave == false)
                {
                    code = objEntity.EmployeeCode.ToString();
                }

                DataRow vdr;
                con = OpenConnection();
                adp.SelectCommand = new SqlCommand();
                vCmBld = new SqlCommandBuilder(adp);
                adp.SelectCommand.Connection = con;
                adp.SelectCommand.CommandText = "SELECT * FROM " + tableName + " WHERE EmployeeCode = '" + code + "'";
                adp.Fill(vDs, tableName);

                if (isSave)
                {
                    vdr = vDs.Tables[tableName].NewRow();

                    vdr["EmployeeCode"] = objEntity.EmployeeCode;
                    vdr["PunchDate"] = DateTime.Now.ToString();
                    vdr["PunchIn"] = DateTime.Now.ToString("HH:mm");

                    vDs.Tables[tableName].Rows.Add(vdr);
                }
                else
                {
                    vdr = vDs.Tables[tableName].Rows[0];
                    vdr["PunchOut"] = DateTime.Now.ToString("HH:mm");
                }

                adp.Update(vDs, tableName);
            }
            catch (Exception ex)
            {
                _strResult = ex.Message;
                return false;
            }
            finally
            {
                con.Close();
                vCmBld.Dispose();
                vDs.Dispose();
                adp.Dispose();
            }

            return true;
        }

    }
}

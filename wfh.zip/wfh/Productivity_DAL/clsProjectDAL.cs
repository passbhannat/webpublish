﻿using System;
using Productivity_BO;
using System.Text;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Productivity_DAL
{
    public class clsProjectDAL : clsDataAccess
    {
        SqlDataAdapter adp = null;
        SqlConnection con = null; 
        DataSet vDs = null;
        SqlCommandBuilder vCmBld = null;

        public List<clsEntity_Master_Project> Get_ProjectMaster(string projectCode)
        {
            List<clsEntity_Master_Project> objList = null;
         
            try
            {
                StringBuilder query = new StringBuilder();

                query.Append(" SELECT T1.ProjectCode, T1.ProjectName, T1.CustomerCode, T2.CustomerName ");
                query.Append(" FROM Master_Project T1 ");
                query.Append(" LEFT JOIN Master_Customer T2 ");
                query.Append(" ON T1.CustomerCode = T2.CustomerCode ");
                query.Append(" WHERE T1.Status = 1 ");

                if (!string.IsNullOrEmpty(projectCode))
                {
                    query.Append(" AND T1.ProjectCode='" + projectCode + "' ");
                }

                using (DataTable datatable = FillDataset(query.ToString(), OpenConnection()).Tables[0])
                {
                    objList = ConvertTo<clsEntity_Master_Project>(datatable);
                }
            }
            catch (Exception ex)
            {

            }

            return objList;
        }

    

        public bool SaveUpdate_ProjectMaster(clsEntity_Master_Project objEntity, bool isSave, out string _strResult)
        {
            _strResult = string.Empty;
            adp = new SqlDataAdapter();
            con = new SqlConnection();
            vDs = new DataSet();
            vCmBld = null;

            try
            {
                string tableName = "Master_Project";
                string code = "0";

                if (isSave == false)
                {
                    code = objEntity.ProjectCode.ToString();
                }

                DataRow vdr;
                con = OpenConnection();
                adp.SelectCommand = new SqlCommand();
                vCmBld = new SqlCommandBuilder(adp);
                adp.SelectCommand.Connection = con;
                adp.SelectCommand.CommandText = "SELECT * FROM " + tableName + " WHERE ProjectCode = '" + code + "'";
                adp.Fill(vDs, tableName);

                if (isSave)
                {
                    vdr = vDs.Tables[tableName].NewRow();

                    vdr["ProjectCode"] = objEntity.ProjectCode;
                    vdr["ProjectName"] = objEntity.ProjectName;
                    vdr["CustomerCode"] = objEntity.CustomerCode;
                    vdr["CreatedDateTime"] = DateTime.Now.ToString();
                    vdr["Status"] = true;

                    vDs.Tables[tableName].Rows.Add(vdr);
                }
                else
                {
                    vdr = vDs.Tables[tableName].Rows[0];

                    vdr["ProjectName"] = objEntity.ProjectName;
                    vdr["CustomerCode"] = objEntity.CustomerCode;
                    vdr["UpdatedDateTime"] = DateTime.Now.ToString();
                }
                               
                adp.Update(vDs, tableName);
            }
            catch (Exception ex)
            {
                _strResult = ex.Message;
                return false;
            }
            finally
            {
                con.Close();
                vCmBld.Dispose();
                vDs.Dispose();
                adp.Dispose();
            }

            return true;
        }

        public List<clsEntity_Master_Project> Get_ProjectList()
        {
            List<clsEntity_Master_Project> objList = null;

            try
            {
                StringBuilder query = new StringBuilder();

                query.Append(" SELECT ProjectCode, ProjectName");
                query.Append(" FROM Master_Project ");
                query.Append(" WHERE Status = 1 ");

                using (DataTable datatable = FillDataset(query.ToString(), OpenConnection()).Tables[0])
                {
                    objList = ConvertTo<clsEntity_Master_Project>(datatable);
                }
            }
            catch (Exception ex)
            {

            }

            return objList;
        }

        public bool DeleteProject(string projectCode)
        {
            try
            {
                string tableName = "Master_Project";
                string query = "UPDATE " + tableName + " SET STATUS = 0 WHERE ProjectCode ='" + projectCode + "' ";
                InsertUpdateDelete_Record(query.ToString(), OpenConnection());
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}

﻿using System;
using Productivity_BO;
using System.Text;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Productivity_DAL
{
    public class clsTaskDAL : clsDataAccess
    {
        SqlDataAdapter adp = null;
        SqlConnection con = null;
        DataSet vDs = null;
        SqlCommandBuilder vCmBld = null;

        #region - Task Updation
        public List<clsEntity_Master_Task> Get_TaskList(string taskUpdationID)
        {
            List<clsEntity_Master_Task> objList = null;

            try
            {
                StringBuilder query = new StringBuilder();

                query.Append(" SELECT T1.TaskUpdationID, T1.EmployeeCode,T2.EmployeeName, T1.ActivityCode, T4.ActivityName, T1.ProjectCode, T3.ProjectName, T1.TransactionCompleted,Convert(varchar,T1.TaskDate,105) [TaskDate], T1.TimeIn, T1.TimeOut ");
                query.Append(" FROM Transaction_TaskUpdation T1 ");
                query.Append(" LEFT JOIN Master_Employee T2 ");
                query.Append(" ON T1.EmployeeCode = T2.EmployeeCode ");
                query.Append(" LEFT JOIN Master_Project T3 ");
                query.Append(" ON T1.ProjectCode = T3.ProjectCode ");
                query.Append(" LEFT JOIN Master_Activity T4 ");
                query.Append(" ON T1.ActivityCode = T4.ActivityCode ");

                if (!string.IsNullOrEmpty(taskUpdationID))
                {
                    query.Append(" WHERE T1.TaskUpdationID='" + taskUpdationID + "' ");
                }

                using (DataTable datatable = FillDataset(query.ToString(), OpenConnection()).Tables[0])
                {
                    objList = ConvertTo<clsEntity_Master_Task>(datatable);
                }
            }
            catch (Exception ex)
            {

            }

            return objList;
        }

        public bool SaveUpdate_Task(clsEntity_Master_Task objEntity, bool isSave, out string _strResult)
    {
            _strResult = string.Empty;
            adp = new SqlDataAdapter();
            con = new SqlConnection();
            vDs = new DataSet();
            vCmBld = null;

            try
            {
                string tableName = "Transaction_TaskUpdation";
                string code = "0";

                if (isSave == false)
                {
                    code = objEntity.TaskUpdationID.ToString();
                }

                DataRow vdr;
                con = OpenConnection();
                adp.SelectCommand = new SqlCommand();
                vCmBld = new SqlCommandBuilder(adp);
                adp.SelectCommand.Connection = con;
                adp.SelectCommand.CommandText = "SELECT * FROM " + tableName + " WHERE TaskUpdationID = '" + code + "'";
                adp.Fill(vDs, tableName);

                if (isSave)
                {
                    vdr = vDs.Tables[tableName].NewRow();

                    vdr["EmployeeCode"] = objEntity.EmployeeCode;
                    vdr["ActivityCode"] = objEntity.ActivityCode;
                    vdr["ProjectCode"] = objEntity.ProjectCode;
                    vdr["TransactionCompleted"] = objEntity.TransactionCompleted;
                    vdr["TaskDate"] = DateTime.Now.ToShortDateString();
                    vdr["TimeIn"] = objEntity.TimeIn;
                    vdr["TimeOut"] = objEntity.TimeOut;

                    vDs.Tables[tableName].Rows.Add(vdr);
                }
                else
                {
                    vdr = vDs.Tables[tableName].Rows[0];

                    vdr["ActivityCode"] = objEntity.ActivityCode;
                    vdr["ProjectCode"] = objEntity.ProjectCode;
                    vdr["TransactionCompleted"] = objEntity.TransactionCompleted;
                    vdr["TimeIn"] = objEntity.TimeIn;
                    vdr["TimeOut"] = objEntity.TimeOut;
                }

                adp.Update(vDs, tableName);
            }
            catch (Exception ex)
            {
                _strResult = ex.Message;
                return false;
            }
            finally
            {
                con.Close();
                vCmBld.Dispose();
                vDs.Dispose();
                adp.Dispose();
            }

            return true;
        }

        #endregion

        #region - Task Allocation
        public List<clsEntity_Master_Task> Get_TaskAllocationList(string taskAllocationID)
        {
            List<clsEntity_Master_Task> objList = null;

            try
            {
                StringBuilder query = new StringBuilder();

                query.Append(" SELECT T1.TaskAllocationID, T1.CustomerCode,T2.CustomerName, T1.ActivityCode, T4.ActivityName, T1.ProjectCode, T3.ProjectName, T1.HourlyTarget, T1.DailyTarget ");
                query.Append(" FROM Transaction_TaskAllocation T1 ");
                query.Append(" LEFT JOIN Master_Customer T2 ");
                query.Append(" ON T1.CustomerCode = T2.CustomerCode ");
                query.Append(" LEFT JOIN Master_Project T3 ");
                query.Append(" ON T1.ProjectCode = T3.ProjectCode ");
                query.Append(" LEFT JOIN Master_Activity T4 ");
                query.Append(" ON T1.ActivityCode = T4.ActivityCode ");

                if (!string.IsNullOrEmpty(taskAllocationID))
                {
                    query.Append(" WHERE T1.TaskAllocationID='" + taskAllocationID + "' ");
                }

                using (DataTable datatable = FillDataset(query.ToString(), OpenConnection()).Tables[0])
                {
                    objList = ConvertTo<clsEntity_Master_Task>(datatable);
                }
            }
            catch (Exception ex)
            {

            }

            return objList;
        }

        public bool SaveUpdate_TaskAllocation(clsEntity_Master_Task objEntity, bool isSave, out string _strResult)
        {
            _strResult = string.Empty;
            adp = new SqlDataAdapter();
            con = new SqlConnection();
            vDs = new DataSet();
            vCmBld = null;

            try
            {
                string tableName = "Transaction_TaskAllocation";
                string code = "0";

                if (isSave == false)
                {
                    code = objEntity.TaskAllocationID.ToString();
                }

                DataRow vdr;
                con = OpenConnection();
                adp.SelectCommand = new SqlCommand();
                vCmBld = new SqlCommandBuilder(adp);
                adp.SelectCommand.Connection = con;
                adp.SelectCommand.CommandText = "SELECT * FROM " + tableName + " WHERE TaskAllocationID = '" + code + "'";
                adp.Fill(vDs, tableName);

                if (isSave)
                {
                    vdr = vDs.Tables[tableName].NewRow();

                    vdr["CustomerCode"] = objEntity.CustomerCode;
                    vdr["ActivityCode"] = objEntity.ActivityCode;
                    vdr["ProjectCode"] = objEntity.ProjectCode;
                    vdr["HourlyTarget"] = objEntity.HourlyTarget;
                    vdr["DailyTarget"] = objEntity.DailyTarget;
                    vdr["CreatedDateTime"] = DateTime.Now;
                    vdr["Status"] = true;

                    vDs.Tables[tableName].Rows.Add(vdr);
                }
                else
                {
                    vdr = vDs.Tables[tableName].Rows[0];

                    vdr["CustomerCode"] = objEntity.CustomerCode;
                    vdr["ActivityCode"] = objEntity.ActivityCode;
                    vdr["ProjectCode"] = objEntity.ProjectCode;
                    vdr["HourlyTarget"] = objEntity.HourlyTarget;
                    vdr["DailyTarget"] = objEntity.DailyTarget;
                    vdr["UpdatedDateTime"] = DateTime.Now;
                }

                adp.Update(vDs, tableName);
            }
            catch (Exception ex)
            {
                _strResult = ex.Message;
                return false;
            }
            finally
            {
                con.Close();
                vCmBld.Dispose();
                vDs.Dispose();
                adp.Dispose();
            }

            return true;
        }

        #endregion
    }
}

﻿using System;
using Productivity_BO;
using System.Text;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Productivity_DAL
{
    public class clsCommonDAL : clsDataAccess
    {
        SqlDataAdapter adp = null;
        SqlConnection con = null; 
        DataSet vDs = null;
        SqlCommandBuilder vCmBld = null;

    }
}

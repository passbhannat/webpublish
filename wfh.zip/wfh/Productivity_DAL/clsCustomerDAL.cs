﻿using System;
using Productivity_BO;
using System.Text;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Productivity_DAL
{
    public class clsCustomerDAL : clsDataAccess
    {
        SqlDataAdapter adp = null;
        SqlConnection con = null; 
        DataSet vDs = null;
        SqlCommandBuilder vCmBld = null;

        public List<clsEntity_Master_Customer> Get_CustomerMaster(string customerCode)
        {
            List<clsEntity_Master_Customer> objList = null;
         
            try
            {
                StringBuilder query = new StringBuilder();

                query.Append(" SELECT [CustomerCode], [CustomerName] FROM Master_Customer WHERE STATUS = 1 ");

                if (!string.IsNullOrEmpty(customerCode))
                {
                    query.Append(" AND customerCode='" + customerCode + "' ");
                }

                using (DataTable datatable = FillDataset(query.ToString(), OpenConnection()).Tables[0])
                {
                    objList = ConvertTo<clsEntity_Master_Customer>(datatable);
                }
            }
            catch (Exception ex)
            {

            }

            return objList;
        }

        public bool SaveUpdate_CustomerMaster(clsEntity_Master_Customer objEntity, bool isSave, out string _strResult)
        {
            _strResult = string.Empty;
            adp = new SqlDataAdapter();
            con = new SqlConnection();
            vDs = new DataSet();
            vCmBld = null;

            try
            {
                string tableName = "Master_Customer";
                string code = "0";

                if (isSave == false)
                {
                    code = objEntity.CustomerCode.ToString();
                }

                DataRow vdr;
                con = OpenConnection();
                adp.SelectCommand = new SqlCommand();
                vCmBld = new SqlCommandBuilder(adp);
                adp.SelectCommand.Connection = con;
                adp.SelectCommand.CommandText = "SELECT * FROM " + tableName + " WHERE CustomerCode = '"+ code + "'";
                adp.Fill(vDs, tableName);

                if (isSave)
                {
                    vdr = vDs.Tables[tableName].NewRow();

                    vdr["CustomerCode"] = objEntity.CustomerCode;
                    vdr["CustomerName"] = objEntity.CustomerName;
                    vdr["CreatedDateTime"] = DateTime.Now.ToString();
                    vdr["Status"] = true;

                    vDs.Tables[tableName].Rows.Add(vdr);
                }
                else
                {
                    vdr = vDs.Tables[tableName].Rows[0];

                    vdr["CustomerName"] = objEntity.CustomerName;
                    vdr["UpdatedDateTime"] = DateTime.Now.ToString();
                }
                               
                adp.Update(vDs, tableName);
            }
            catch (Exception ex)
            {
                _strResult = ex.Message;
                return false;
            }
            finally
            {
                con.Close();
                vCmBld.Dispose();
                vDs.Dispose();
                adp.Dispose();
            }

            return true;
        }

        public bool DeleteCustomer(string customerCode)
        {
            try
            {
                string tableName = "Master_Customer";
                string query = "UPDATE " + tableName + " SET STATUS = 0 WHERE CustomerCode ='" + customerCode + "' ";
                InsertUpdateDelete_Record(query.ToString(), OpenConnection());
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}

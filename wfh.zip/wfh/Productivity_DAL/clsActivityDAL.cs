﻿using System;
using Productivity_BO;
using System.Text;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Productivity_DAL
{
    public class clsActivityDAL : clsDataAccess
    {
        SqlDataAdapter adp = null;
        SqlConnection con = null; 
        DataSet vDs = null;
        SqlCommandBuilder vCmBld = null;

        public List<clsEntity_Master_Activity> Get_ActivityMaster(string ActivityCode)
        {
            List<clsEntity_Master_Activity> objList = null;

            try
            {
                StringBuilder query = new StringBuilder();

                query.Append(" SELECT T1.ActivityCode, T1.ActivityName, T1.CustomerCode, T1.ProjectCode, T2.CustomerName, T3.ProjectName ");
                query.Append(" FROM Master_Activity T1 ");
                query.Append(" LEFT JOIN Master_Customer T2 ");
                query.Append(" ON T1.CustomerCode = T2.CustomerCode ");
                query.Append(" LEFT JOIN Master_Project T3 ");
                query.Append(" ON T1.ProjectCode = T3.ProjectCode ");
                query.Append(" WHERE T1.STATUS = 1 ");

                if (!string.IsNullOrEmpty(ActivityCode))
                {
                    query.Append(" AND T1.ActivityCode='" + ActivityCode + "' ");
                }

                using (DataTable datatable = FillDataset(query.ToString(), OpenConnection()).Tables[0])
                {
                    objList = ConvertTo<clsEntity_Master_Activity>(datatable);
                }
            }
            catch (Exception ex)
            {

            }

            return objList;
        }

        public bool SaveUpdate_ActivityMaster(clsEntity_Master_Activity objEntity, bool isSave, out string _strResult)
        {
            _strResult = string.Empty;
            adp = new SqlDataAdapter();
            con = new SqlConnection();
            vDs = new DataSet();
            vCmBld = null;

            try
            {
                string tableName = "Master_Activity";
                string code = "0";

                if (isSave == false)
                {
                    code = objEntity.ActivityCode.ToString();
                }

                DataRow vdr;
                con = OpenConnection();
                adp.SelectCommand = new SqlCommand();
                vCmBld = new SqlCommandBuilder(adp);
                adp.SelectCommand.Connection = con;
                adp.SelectCommand.CommandText = "SELECT * FROM " + tableName + " WHERE ActivityCode = '" + code + "'";
                adp.Fill(vDs, tableName);

                if (isSave)
                {
                    vdr = vDs.Tables[tableName].NewRow();

                    vdr["ActivityCode"] = objEntity.ActivityCode;
                    vdr["ActivityName"] = objEntity.ActivityName;
                    vdr["CustomerCode"] = objEntity.CustomerCode;
                    vdr["ProjectCode"] = objEntity.ProjectCode;
                    vdr["CreatedDateTime"] = DateTime.Now.ToString();
                    vdr["Status"] = true;

                    vDs.Tables[tableName].Rows.Add(vdr);
                }
                else
                {
                    vdr = vDs.Tables[tableName].Rows[0];

                    vdr["ActivityName"] = objEntity.ActivityName;
                    vdr["CustomerCode"] = objEntity.CustomerCode;
                    vdr["ProjectCode"] = objEntity.ProjectCode;
                    vdr["UpdatedDateTime"] = DateTime.Now.ToString();
                }

                adp.Update(vDs, tableName);
            }
            catch (Exception ex)
            {
                _strResult = ex.Message;
                return false;
            }
            finally
            {
                con.Close();
                vCmBld.Dispose();
                vDs.Dispose();
                adp.Dispose();
            }

            return true;
        }

        public List<clsEntity_Master_Activity> Get_ActivityList()
        {
            List<clsEntity_Master_Activity> objList = null;

            try
            {
                StringBuilder query = new StringBuilder();

                query.Append(" SELECT ActivityCode, ActivityName");
                query.Append(" FROM Master_Activity ");
                query.Append(" WHERE Status = 1 ");

                using (DataTable datatable = FillDataset(query.ToString(), OpenConnection()).Tables[0])
                {
                    objList = ConvertTo<clsEntity_Master_Activity>(datatable);
                }
            }
            catch (Exception ex)
            {

            }

            return objList;
        }
        public bool DeleteActivity(string activityCode)
        {
            try
            {
                string tableName = "Master_Activity";
                string query = "UPDATE " + tableName + " SET STATUS = 0 WHERE ActivityCode ='" + activityCode + "' ";
                InsertUpdateDelete_Record(query.ToString(), OpenConnection());
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


    }
}

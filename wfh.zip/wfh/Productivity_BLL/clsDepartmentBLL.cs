﻿using System;
using Productivity_BO;
using Productivity_DAL;
using System.Collections.Generic;

namespace Productivity_BLL
{
    public class clsDepartmentBLL
    {
        clsDepartmentDAL _DepartmentDAL = null;

        public clsDepartmentBLL()
        {
            _DepartmentDAL = new clsDepartmentDAL();
        }

        public List<clsEntity_Master_Department> Get_DepartmentMaster(string DepartmentCode)
        {
            List<clsEntity_Master_Department> objList = _DepartmentDAL.Get_DepartmentMaster(DepartmentCode);
            return objList;
        }

        public bool SaveUpdate_DepartmentMaster(clsEntity_Master_Department objEntity, out string _strResult)
        {
            string DepartmentCode = objEntity.DepartmentCode;
            _strResult = "0";
            bool _boolsuccess;

            try
            {

               var data = _DepartmentDAL.Get_DepartmentMaster(DepartmentCode);
                if(data.Count > 0)
                {
                    _boolsuccess = _DepartmentDAL.SaveUpdate_DepartmentMaster(objEntity, false, out _strResult);
                  
                    if (_boolsuccess == true)
                    {
                        _strResult = "Record updated successfully";
                    }
                }
                else
                {
                    _boolsuccess = _DepartmentDAL.SaveUpdate_DepartmentMaster(objEntity, true, out _strResult);
                   
                    if (_boolsuccess == true)
                    {
                        _strResult = "Record added successfully";
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                _strResult = ex.Message;
                return false;
            }
        }

        public bool DeleteDepartment(string departmentCode)
        {
            try
            {
                if (_DepartmentDAL.DeleteDepartment(departmentCode) == true)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {

            }
            return false;
        }
    }
}

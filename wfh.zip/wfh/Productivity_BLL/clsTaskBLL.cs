﻿using System;
using Productivity_BO;
using Productivity_DAL;
using System.Collections.Generic;

namespace Productivity_BLL
{
    public class clsTaskBLL
    {
        clsTaskDAL _TaskDAL = null;

        public clsTaskBLL()
        {
            _TaskDAL = new clsTaskDAL();
        }

        #region - Task Updation
        public List<clsEntity_Master_Task> Get_TaskList(string taskUpdationID)
        {
            List<clsEntity_Master_Task> objList = _TaskDAL.Get_TaskList(taskUpdationID);
            return objList;
        }

        public bool SaveUpdate_Task(clsEntity_Master_Task objEntity, out string _strResult)
        {
            string taskCode = objEntity.TaskUpdationID;
            _strResult = "0";
            bool _boolsuccess;

            try
            {
                if(!string.IsNullOrEmpty(taskCode))
                {
                    _boolsuccess = _TaskDAL.SaveUpdate_Task(objEntity, false, out _strResult);
                  
                    if (_boolsuccess == true)
                    {
                        _strResult = "Record updated successfully";
                    }
                }
                else
                {
                    _boolsuccess = _TaskDAL.SaveUpdate_Task(objEntity, true, out _strResult);
                   
                    if (_boolsuccess == true)
                    {
                        _strResult = "Record added successfully";
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                _strResult = ex.Message;
                return false;
            }
        }

        #endregion

        #region - Task Allocation

        public List<clsEntity_Master_Task> Get_TaskAllocationList(string taskAllocationID)
        {
            List<clsEntity_Master_Task> objList = _TaskDAL.Get_TaskAllocationList(taskAllocationID);
            return objList;
        }

        public bool SaveUpdate_TaskAllocation(clsEntity_Master_Task objEntity, out string _strResult)
        {
            string taskCode = objEntity.TaskAllocationID;
            _strResult = "0";
            bool _boolsuccess;

            try
            {
                if (!string.IsNullOrEmpty(taskCode))
                {
                    _boolsuccess = _TaskDAL.SaveUpdate_TaskAllocation(objEntity, false, out _strResult);

                    if (_boolsuccess == true)
                    {
                        _strResult = "Record updated successfully";
                    }
                }
                else
                {
                    _boolsuccess = _TaskDAL.SaveUpdate_TaskAllocation(objEntity, true, out _strResult);

                    if (_boolsuccess == true)
                    {
                        _strResult = "Record added successfully";
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                _strResult = ex.Message;
                return false;
            }
        }

        #endregion

    }
}

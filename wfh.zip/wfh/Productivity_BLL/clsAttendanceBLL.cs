﻿using System;
using Productivity_BO;
using Productivity_DAL;
using System.Collections.Generic;

namespace Productivity_BLL
{
    public class clsAttendanceBLL
    {
        clsAttendanceDAL _clsAttendanceDAL = null;

        public clsAttendanceBLL()
        {
            _clsAttendanceDAL = new clsAttendanceDAL();
        }

        public List<clsEntity_Master_Attendance> Get_AttendanceList(string employeeCode)
        {
            List<clsEntity_Master_Attendance> objList = _clsAttendanceDAL.Get_AttendanceList(employeeCode);
            return objList;
        }

        public List<clsEntity_Master_Attendance> Get_AttendanceByEmployeeDate(string employeeCode)
        {
            List<clsEntity_Master_Attendance> objList = _clsAttendanceDAL.Get_AttendanceByEmployeeDate(employeeCode);
            return objList;
        }

        public bool PunchIn(clsEntity_Master_Attendance objEntity, out string _strResult)
        {
            _strResult = "0";
            bool _boolsuccess;

            try
            {
                var data = _clsAttendanceDAL.Get_AttendanceByEmployeeDate(objEntity.EmployeeCode);

                if (data.Count > 0)
                {
                    _boolsuccess = _clsAttendanceDAL.PunchIn(objEntity, false, out _strResult);

                    if (_boolsuccess == true)
                    {
                        _strResult = "Attendance Punch Out successfully";
                    }
                }
                else
                {
                    _boolsuccess = _clsAttendanceDAL.PunchIn(objEntity, true, out _strResult);

                    if (_boolsuccess == true)
                    {
                        _strResult = "Attendance Punch In successfully";
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                _strResult = ex.Message;
                return false;
            }
        }


    }
}

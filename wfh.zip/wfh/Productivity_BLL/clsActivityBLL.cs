﻿using System;
using Productivity_BO;
using Productivity_DAL;
using System.Collections.Generic;

namespace Productivity_BLL
{
    public class clsActivityBLL
    {
        clsActivityDAL _ActivityDAL = null;

        public clsActivityBLL()
        {
            _ActivityDAL = new clsActivityDAL();
        }

        public List<clsEntity_Master_Activity> Get_ActivityMaster(string ActivityCode)
        {
            List<clsEntity_Master_Activity> objList = _ActivityDAL.Get_ActivityMaster(ActivityCode);
            return objList;
        }

        public bool SaveUpdate_ActivityMaster(clsEntity_Master_Activity objEntity, out string _strResult)
        {
            string ActivityCode = objEntity.ActivityCode;
            _strResult = "0";
            bool _boolsuccess;

            try
            {

               var data = _ActivityDAL.Get_ActivityMaster(ActivityCode);
                if(data.Count > 0)
                {
                    _boolsuccess = _ActivityDAL.SaveUpdate_ActivityMaster(objEntity, false, out _strResult);
                  
                    if (_boolsuccess == true)
                    {
                        _strResult = "Record updated successfully";
                    }
                }
                else
                {
                    _boolsuccess = _ActivityDAL.SaveUpdate_ActivityMaster(objEntity, true, out _strResult);
                   
                    if (_boolsuccess == true)
                    {
                        _strResult = "Record added successfully";
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                _strResult = ex.Message;
                return false;
            }
        }

        public List<clsEntity_Master_Activity> Get_ActivityList()
        {
            List<clsEntity_Master_Activity> objList = _ActivityDAL.Get_ActivityList();
            return objList;
        }

        public bool DeleteActivity(string activityCode)
        {
            try
            {
                if (_ActivityDAL.DeleteActivity(activityCode) == true)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {

            }
            return false;
        }

    }
}

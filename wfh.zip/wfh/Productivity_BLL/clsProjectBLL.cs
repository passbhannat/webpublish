﻿using System;
using Productivity_BO;
using Productivity_DAL;
using System.Collections.Generic;

namespace Productivity_BLL
{
    public class clsProjectBLL
    {
        clsProjectDAL _ProjectDAL = null;

        public clsProjectBLL()
        {
            _ProjectDAL = new clsProjectDAL();
        }

        public List<clsEntity_Master_Project> Get_ProjectMaster(string ProjectCode)
        {
            List<clsEntity_Master_Project> objList = _ProjectDAL.Get_ProjectMaster(ProjectCode);
            return objList;
        }
      
        public bool SaveUpdate_ProjectMaster(clsEntity_Master_Project objEntity, out string _strResult)
        {
            string ProjectCode = objEntity.ProjectCode;
            _strResult = "0";
            bool _boolsuccess;

            try
            {

               var data = _ProjectDAL.Get_ProjectMaster(ProjectCode);
                if(data.Count > 0)
                {
                    _boolsuccess = _ProjectDAL.SaveUpdate_ProjectMaster(objEntity, false, out _strResult);
                  
                    if (_boolsuccess == true)
                    {
                        _strResult = "Record updated successfully";
                    }
                }
                else
                {
                    _boolsuccess = _ProjectDAL.SaveUpdate_ProjectMaster(objEntity, true, out _strResult);
                   
                    if (_boolsuccess == true)
                    {
                        _strResult = "Record added successfully";
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                _strResult = ex.Message;
                return false;
            }
        }
        
        public List<clsEntity_Master_Project> Get_ProjectList()
        {
            List<clsEntity_Master_Project> objList = _ProjectDAL.Get_ProjectList();
            return objList;
        }

        public bool DeleteProject(string projectCode)
        {
            try
            {
                if (_ProjectDAL.DeleteProject(projectCode) == true)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {

            }
            return false;
        }
    }
}

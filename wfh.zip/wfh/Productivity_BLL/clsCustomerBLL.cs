﻿using System;
using Productivity_BO;
using Productivity_DAL;
using System.Collections.Generic;

namespace Productivity_BLL
{
    public class clsCustomerBLL
    {
        clsCustomerDAL _customerDAL = null;

        public clsCustomerBLL()
        {
            _customerDAL = new clsCustomerDAL();
        }

        public List<clsEntity_Master_Customer> Get_CustomerMaster(string customerCode)
        {
            List<clsEntity_Master_Customer> objList = _customerDAL.Get_CustomerMaster(customerCode);
            return objList;
        }

        public bool SaveUpdate_CustomerMaster(clsEntity_Master_Customer objEntity, out string _strResult)
        {
            string customerCode = objEntity.CustomerCode;
            _strResult = "0";
            bool _boolsuccess;

            try
            {

               var data = _customerDAL.Get_CustomerMaster(customerCode);
                if(data.Count > 0)
                {
                    _boolsuccess = _customerDAL.SaveUpdate_CustomerMaster(objEntity, false, out _strResult);
                  
                    if (_boolsuccess == true)
                    {
                        _strResult = "Record updated successfully";
                    }
                }
                else
                {
                    _boolsuccess = _customerDAL.SaveUpdate_CustomerMaster(objEntity, true, out _strResult);
                   
                    if (_boolsuccess == true)
                    {
                        _strResult = "Record added successfully";
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                _strResult = ex.Message;
                return false;
            }
        }

        public bool DeleteCustomer(string customerCode)
        {
            try
            {
                if (_customerDAL.DeleteCustomer(customerCode) == true)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {

            }
            return false;
        }

    }
}

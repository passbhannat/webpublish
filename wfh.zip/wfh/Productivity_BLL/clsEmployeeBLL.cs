﻿using System;
using Productivity_BO;
using Productivity_DAL;
using System.Collections.Generic;

namespace Productivity_BLL
{
    public class clsEmployeeBLL
    {
        clsEmployeeDAL _EmployeeDAL = null;

        public clsEmployeeBLL()
        {
            _EmployeeDAL = new clsEmployeeDAL();
        }

        public List<clsEntity_Master_Employee> Get_EmployeeMaster(string EmployeeCode)
        {
            List<clsEntity_Master_Employee> objList = _EmployeeDAL.Get_EmployeeMaster(EmployeeCode);
            return objList;
        }

        public bool SaveUpdate_EmployeeMaster(clsEntity_Master_Employee objEntity, out string _strResult)
        {
            string EmployeeCode = objEntity.EmployeeCode;
            _strResult = "0";
            bool _boolsuccess;

            try
            {

               var data = _EmployeeDAL.Get_EmployeeMaster(EmployeeCode);
                if(data.Count > 0)
                {
                    _boolsuccess = _EmployeeDAL.SaveUpdate_EmployeeMaster(objEntity, false, out _strResult);
                  
                    if (_boolsuccess == true)
                    {
                        _strResult = "Record updated successfully";
                    }
                }
                else
                {
                    _boolsuccess = _EmployeeDAL.SaveUpdate_EmployeeMaster(objEntity, true, out _strResult);
                   
                    if (_boolsuccess == true)
                    {
                        _strResult = "Record added successfully";
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                _strResult = ex.Message;
                return false;
            }
        }

        public List<clsEntity_Master_Employee> Get_EmployeeList()
        {
            List<clsEntity_Master_Employee> objList = _EmployeeDAL.Get_EmployeeList();
            return objList;
        }

        public bool DeleteEmployee(string employeeCode)
        {
            try
            {
                if (_EmployeeDAL.DeleteEmployee(employeeCode) == true)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {

            }
            return false;
        }
    }
}

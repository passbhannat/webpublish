﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Productivity.Models
{
    public class AttendanceModel
    {
        public string AttendanceId { get; set; }
        public string EmployeeCode { get; set; }
        public string PunchDate { get; set; }
        public string PunchIn { get; set; }
        public string PunchOut { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Productivity.Models
{
    public class DepartmentModel
    {

        [Required(ErrorMessage = "Enter Department Code")]
        public string DepartmentCode { get; set; }

        [Required(ErrorMessage = "Enter Department Name")]

        public string DepartmentName { get; set; }
        public string CreatedDateTime { get; set; }
        public string UpdatedDateTime { get; set; }
        public bool Status { get; set; }
    }
}
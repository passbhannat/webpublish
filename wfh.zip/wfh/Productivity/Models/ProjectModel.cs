﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Productivity.Models
{
    public class ProjectModel
    {

        [Required(ErrorMessage = "Enter Project Code")]
        public string ProjectCode { get; set; }

        [Required(ErrorMessage = "Enter Project Name")]
        public string ProjectName { get; set; }


        [Required(ErrorMessage = "Enter Customer Name")]
        public string CustomerCode { get; set; }

        public string CreatedDateTime { get; set; }
        public string UpdatedDateTime { get; set; }
        public bool Status { get; set; }
    }
}
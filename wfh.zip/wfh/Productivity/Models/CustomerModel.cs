﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Productivity.Models
{
    public class CustomerModel
    {

        [Required(ErrorMessage = "Enter Customer Code")]
        public string CustomerCode { get; set; }

        [Required(ErrorMessage = "Enter Customer Name")]

        public string CustomerName { get; set; }
        public string CreatedDateTime { get; set; }
        public string UpdatedDateTime { get; set; }
        public bool Status { get; set; }
    }
}
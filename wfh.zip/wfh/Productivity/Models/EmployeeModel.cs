﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Productivity.Models
{
    public class EmployeeModel
    {

        [Required(ErrorMessage = "Enter Employee Code")]
        public string EmployeeCode { get; set; }

        [Required(ErrorMessage = "Enter Employee Name")]
        public string EmployeeName { get; set; }
        public string MobileNo { get; set; }

        public string SupervisorEmployeeCode { get; set; }


        [Required(ErrorMessage = "Enter Customer Name")]
        public string CustomerCode { get; set; }

        [Required(ErrorMessage = "Enter Project Name")]
        public string ProjectCode { get; set; }


        [Required(ErrorMessage = "Enter Department Name")]
        public string DepartmentCode { get; set; }

        public string CreatedDateTime { get; set; }
        public string UpdatedDateTime { get; set; }
        public bool Status { get; set; }
    }
}
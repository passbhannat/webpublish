﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Productivity.Models
{
    public class ActivityModel
    {

        [Required(ErrorMessage = "Enter Activity Code")]
        public string ActivityCode { get; set; }

        [Required(ErrorMessage = "Enter Activity Name")]
        public string ActivityName { get; set; }


        [Required(ErrorMessage = "Enter Customer Name")]
        public string CustomerCode { get; set; }

        [Required(ErrorMessage = "Enter Project Name")]
        public string ProjectCode { get; set; }

        public string CreatedDateTime { get; set; }
        public string UpdatedDateTime { get; set; }
        public bool Status { get; set; }
    }
}
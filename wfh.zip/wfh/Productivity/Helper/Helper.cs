﻿using System;
using System.Collections.Generic;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Web;

namespace Productivity.Helper
{
    public class Helper
    {
        public static string getGurrentUsername
        {
            get
            {
                var fullnameclaim = System.Environment.UserName;

                PrincipalContext ctx = new PrincipalContext(ContextType.Domain);
                //UserPrincipal user = UserPrincipal.FindByIdentity(ctx, HttpContext.Current.User.Identity.Name);  // for Server
                UserPrincipal user = UserPrincipal.FindByIdentity(ctx, fullnameclaim);  // for Local
                string fullname = user.DisplayName;
                return fullname;
            }
        }

    }
}


//View:
//string fullname = Helper.GetCurrentUserNames;


//web.config:
//<authentication mode = "Windows" />

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;

namespace Productivity.Controllers
{
    public class HomeController : Controller
    {
        //[Authorize]
        public ActionResult Index()
        {   
            string username = Helper.Helper.getGurrentUsername;
            ViewBag.Username = username;
            return View();
        }
    }
}
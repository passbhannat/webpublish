﻿using Productivity.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Productivity_BO;
using Productivity_BLL;

namespace Productivity.Controllers
{
    public class ProjectController : Controller
    {
        clsProjectBLL _clsProjectBLL = null;

        public ProjectController()
        {
            _clsProjectBLL = new clsProjectBLL();
        }

        // GET: Project
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult Get_ProjectMaster()
        {
            List<clsEntity_Master_Project> list = _clsProjectBLL.Get_ProjectMaster("");
            return Json(new { aaData = list }, JsonRequestBehavior.AllowGet);
        }

        //[Authorize]
        [HttpGet]
        public ActionResult Project(string ProjectCode)
        {
            ViewBag.CustomerList = GetCustomerList();

            if (string.IsNullOrEmpty(ProjectCode) == false)
            {
                List<clsEntity_Master_Project> obj = _clsProjectBLL.Get_ProjectMaster(ProjectCode);
                
                var _model = new ProjectModel
                {
                    ProjectCode = obj[0].ProjectCode,
                    ProjectName = obj[0].ProjectName,
                    CustomerCode = obj[0].CustomerCode,
                };

                return View(_model);
            }


            return View();
        }

        // Post Data
        //[Authorize]
        [HttpPost]
        public ActionResult Project(ProjectModel obj)
        {
            if (ModelState.IsValid)
            {
                // Add Values in Entity
                clsEntity_Master_Project _objEntity = new clsEntity_Master_Project()
                {
                    ProjectCode = obj.ProjectCode,
                    ProjectName = obj.ProjectName,
                    CustomerCode = obj.CustomerCode,
                };

                string _strresult = string.Empty;
                
                bool _boolResult = _clsProjectBLL.SaveUpdate_ProjectMaster(_objEntity, out _strresult);

                ViewBag.Success = _boolResult;
                ViewBag.Message = _strresult;

                return Content(_strresult);
            }
           
            return View();
        }

        [NonAction]
        private SelectList GetCustomerList()
        {
            clsCustomerBLL _clsCustomerBLL = new clsCustomerBLL();
            return new SelectList(_clsCustomerBLL.Get_CustomerMaster(""), "CustomerCode", "CustomerName");
        }

        // Delete
        [HttpPost]
        public void DeleteProject(string projectCode)
        {
            _clsProjectBLL.DeleteProject(projectCode);
        }

    }
}
﻿using Productivity_BLL;
using Productivity_BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Productivity.Models;

namespace Productivity.Controllers
{
    public class AttendanceController : Controller
    {
        clsAttendanceBLL _clsAttendanceBLL = null;
        string employeeCode;

        public AttendanceController()
        {
            _clsAttendanceBLL = new clsAttendanceBLL();
            employeeCode = "1";     // get employee code from login 
        }

        public ActionResult Index()
        {
            ViewBag.CurrentDate = DateTime.Now.ToShortDateString();

            if (!string.IsNullOrEmpty(employeeCode))
            {
                var obj = _clsAttendanceBLL.Get_AttendanceByEmployeeDate(employeeCode);
                if (obj.Count > 0) {
                    var _model = new AttendanceModel
                    {
                        PunchDate = obj[0].PunchDate,
                        PunchIn = obj[0].PunchIn,
                        PunchOut = obj[0].PunchOut,
                    };
                    return View(_model);
                }
                return View();
            }

            return View();
        }

        public JsonResult Get_AttendanceList()
        {

            List<clsEntity_Master_Attendance> list = _clsAttendanceBLL.Get_AttendanceList(employeeCode);
            return Json(new { aaData = list }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult PunchIn()
        {
            try
            {
                clsEntity_Master_Attendance _objEntity = new clsEntity_Master_Attendance()
                {
                    EmployeeCode = employeeCode,
                };

                string _strresult = string.Empty;

                bool _boolResult = _clsAttendanceBLL.PunchIn(_objEntity, out _strresult);

                ViewBag.Success = _boolResult;
                ViewBag.Message = _strresult;

                return Content(_strresult);
            }
            catch (Exception ex)
            {

            }

            return View();
        }
    }
}
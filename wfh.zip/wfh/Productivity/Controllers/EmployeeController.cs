﻿using Productivity.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Productivity_BO;
using Productivity_BLL;

namespace Productivity.Controllers
{
    public class EmployeeController : Controller
    {
        clsEmployeeBLL _clsEmployeeBLL = null;

        public EmployeeController()
        {
            _clsEmployeeBLL = new clsEmployeeBLL();
        }

        // GET: Employee
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult Get_EmployeeMaster()
        {
            List<clsEntity_Master_Employee> list = _clsEmployeeBLL.Get_EmployeeMaster("");
            return Json(new { aaData = list }, JsonRequestBehavior.AllowGet);
        }

        //[Authorize]
        [HttpGet]
        public ActionResult Employee(string EmployeeCode)
        {
            ViewBag.CustomerList = GetCustomerList();
            ViewBag.ProjectList = GetProjectList();
            ViewBag.DepartmentList = GetDepartmentList();
            ViewBag.EmployeeList = GetEmployeeList();

            if (string.IsNullOrEmpty(EmployeeCode) == false)
            {
                List<clsEntity_Master_Employee> obj = _clsEmployeeBLL.Get_EmployeeMaster(EmployeeCode);
                
                var _model = new EmployeeModel
                {
                    EmployeeCode = obj[0].EmployeeCode,
                    EmployeeName = obj[0].EmployeeName,
                    MobileNo = obj[0].MobileNo,
                    SupervisorEmployeeCode = obj[0].SupervisorEmployeeCode,
                    CustomerCode = obj[0].CustomerCode,
                    ProjectCode = obj[0].ProjectCode,
                    DepartmentCode = obj[0].DepartmentCode
                };

                return View(_model);
            }


            return View();
        }

        // Post Data
        //[Authorize]
        [HttpPost]
        public ActionResult Employee(EmployeeModel obj)
        {
            if (ModelState.IsValid)
            {
                // Add Values in Entity
                clsEntity_Master_Employee _objEntity = new clsEntity_Master_Employee()
                {
                    EmployeeCode = obj.EmployeeCode,
                    EmployeeName = obj.EmployeeName,
                    MobileNo = obj.MobileNo,
                    SupervisorEmployeeCode = obj.SupervisorEmployeeCode,
                    CustomerCode = obj.CustomerCode,
                    ProjectCode = obj.ProjectCode,
                    DepartmentCode = obj.DepartmentCode                   
                };

                string _strresult = string.Empty;
                
                bool _boolResult = _clsEmployeeBLL.SaveUpdate_EmployeeMaster(_objEntity, out _strresult);

                ViewBag.Success = _boolResult;
                ViewBag.Message = _strresult;

                return Content(_strresult);
            }
           
            return View();
        }

        [NonAction]
        private SelectList GetCustomerList()
        {
            clsCustomerBLL _clsCustomerBLL = new clsCustomerBLL();
            return new SelectList(_clsCustomerBLL.Get_CustomerMaster(""), "CustomerCode", "CustomerName");
        }

        [NonAction]
        private SelectList GetProjectList()
        {
            clsProjectBLL _clsProjectBLL = new clsProjectBLL();
            return new SelectList(_clsProjectBLL.Get_ProjectList(), "ProjectCode", "ProjectName");
        }

        [NonAction]
        private SelectList GetDepartmentList()
        {
            clsDepartmentBLL _clsDepartmentBLL = new clsDepartmentBLL();
            return new SelectList(_clsDepartmentBLL.Get_DepartmentMaster(""), "DepartmentCode", "DepartmentName");
        }

        [NonAction]
        private SelectList GetEmployeeList()
        {
            return new SelectList(_clsEmployeeBLL.Get_EmployeeList(), "EmployeeCode", "EmployeeName");
        }

        // Delete
        [HttpPost]
        public void DeleteEmployee(string employeeCode)
        {
            _clsEmployeeBLL.DeleteEmployee(employeeCode);
        }

    }
}
﻿using Productivity.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Productivity_BO;
using Productivity_BLL;

namespace Productivity.Controllers
{
    public class CustomerController : Controller
    {
        clsCustomerBLL _clsCustomerBLL = null;

        public CustomerController()
        {
            _clsCustomerBLL = new clsCustomerBLL();
        }

        // GET: Customer
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult Get_CustomerMaster()
        {
            List<clsEntity_Master_Customer> list = _clsCustomerBLL.Get_CustomerMaster("");
            return Json(new { aaData = list }, JsonRequestBehavior.AllowGet);
        }

        //[Authorize]
        [HttpGet]
        public ActionResult Customer(string customerCode)
        { 
            if (string.IsNullOrEmpty(customerCode) == false)
            {
                List<clsEntity_Master_Customer> obj = _clsCustomerBLL.Get_CustomerMaster(customerCode);
                
                var _model = new CustomerModel
                {
                    CustomerCode = obj[0].CustomerCode,
                    CustomerName = obj[0].CustomerName,
                };

                return View(_model);
            }
            return View();
        }

        // Post Data
        //[Authorize]
        [HttpPost]
        public ActionResult Customer(CustomerModel obj)
        {
            if (ModelState.IsValid)
            {
                // Add Values in Entity
                clsEntity_Master_Customer _objEntity = new clsEntity_Master_Customer()
                {
                    CustomerCode = obj.CustomerCode,
                    CustomerName = obj.CustomerName,
                };

                string _strresult = string.Empty;
                
                bool _boolResult = _clsCustomerBLL.SaveUpdate_CustomerMaster(_objEntity, out _strresult);

                ViewBag.Success = _boolResult;
                ViewBag.Message = _strresult;

                return Content(_strresult);
            }
           
            return View();
        }

        // Delete
        [HttpPost]
        public void DeleteCustomer(string customerCode)
        {
            _clsCustomerBLL.DeleteCustomer(customerCode);
        }

    }
}
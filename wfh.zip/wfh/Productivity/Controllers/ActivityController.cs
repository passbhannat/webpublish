﻿using Productivity.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Productivity_BO;
using Productivity_BLL;

namespace Productivity.Controllers
{
    public class ActivityController : Controller
    {
        clsActivityBLL _clsActivityBLL = null;

        public ActivityController()
        {
            _clsActivityBLL = new clsActivityBLL();
        }

        // GET: Activity
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult Get_ActivityMaster()
        {
            List<clsEntity_Master_Activity> list = _clsActivityBLL.Get_ActivityMaster("");
            return Json(new { aaData = list }, JsonRequestBehavior.AllowGet);
        }

        //[Authorize]
        [HttpGet]
        public ActionResult Activity(string ActivityCode)
        {
            ViewBag.CustomerList = GetCustomerList();
            ViewBag.ProjectList = GetProjectList();

            if (string.IsNullOrEmpty(ActivityCode) == false)
            {
                List<clsEntity_Master_Activity> obj = _clsActivityBLL.Get_ActivityMaster(ActivityCode);
                
                var _model = new ActivityModel
                {
                    ActivityCode = obj[0].ActivityCode,
                    ActivityName = obj[0].ActivityName,
                    CustomerCode = obj[0].CustomerCode,
                    ProjectCode = obj[0].ProjectCode,
                };

                return View(_model);
            }


            return View();
        }

        // Post Data
        //[Authorize]
        [HttpPost]
        public ActionResult Activity(ActivityModel obj)
        {
            if (ModelState.IsValid)
            {
                // Add Values in Entity
                clsEntity_Master_Activity _objEntity = new clsEntity_Master_Activity()
                {
                    ActivityCode = obj.ActivityCode,
                    ActivityName = obj.ActivityName,
                    CustomerCode = obj.CustomerCode,
                    ProjectCode = obj.ProjectCode,
                };

                string _strresult = string.Empty;
                
                bool _boolResult = _clsActivityBLL.SaveUpdate_ActivityMaster(_objEntity, out _strresult);

                ViewBag.Success = _boolResult;
                ViewBag.Message = _strresult;

                return Content(_strresult);
            }
           
            return View();
        }

        [NonAction]
        private SelectList GetCustomerList()
        {
            clsCustomerBLL _clsCustomerBLL = new clsCustomerBLL();
            return new SelectList(_clsCustomerBLL.Get_CustomerMaster(""), "CustomerCode", "CustomerName");
        }

        [NonAction]
        private SelectList GetProjectList()
        {
            clsProjectBLL _clsProjectBLL = new clsProjectBLL();
            return new SelectList(_clsProjectBLL.Get_ProjectList(), "ProjectCode", "ProjectName");
        }

        // Delete
        [HttpPost]
        public void DeleteActivity(string activityCode)
        {
            _clsActivityBLL.DeleteActivity(activityCode);
        }
    }
}
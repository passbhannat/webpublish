﻿using Productivity.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Productivity_BO;
using Productivity_BLL;

namespace Productivity.Controllers
{
    public class TaskController : Controller
    {
        clsTaskBLL _clsTaskBLL = null;

        public TaskController()
        {
            _clsTaskBLL = new clsTaskBLL();
        }

        #region - Task Updation

        public ActionResult Index()
        {
            return View();
        }

        public JsonResult Get_TaskList()
        {
            List<clsEntity_Master_Task> list = _clsTaskBLL.Get_TaskList("");
            return Json(new { aaData = list }, JsonRequestBehavior.AllowGet);
        }

        //[Authorize]
        [HttpGet]
        public ActionResult Task(string taskUpdationID)
        {
            ViewBag.EmployeeList = GetEmployeeList();
            ViewBag.ProjectList = GetProjectList();
            ViewBag.ActivityList = GetActivityList();

            if (string.IsNullOrEmpty(taskUpdationID) == false)
            {
                var obj = _clsTaskBLL.Get_TaskList(taskUpdationID);
                if (obj.Count > 0)
                {
                    var _model = new TaskModel
                    {
                        TaskUpdationID = obj[0].TaskUpdationID,
                        EmployeeCode = obj[0].EmployeeCode,
                        ActivityCode = obj[0].ActivityCode,
                        ProjectCode = obj[0].ProjectCode,
                        TransactionCompleted = obj[0].TransactionCompleted,
                        TimeIn = obj[0].TimeIn,
                        TimeOut = obj[0].TimeOut,
                    };

                    return View(_model);
                }
            }

            return View();
        }

        // Post Data
        //[Authorize]
        [HttpPost]
        public ActionResult Task(TaskModel obj)
        {
            if (ModelState.IsValid)
            {
                clsEntity_Master_Task _objEntity = new clsEntity_Master_Task()
                {
                    TaskUpdationID= obj.TaskUpdationID,
                    EmployeeCode = obj.EmployeeCode,
                    ActivityCode = obj.ActivityCode,
                    ProjectCode = obj.ProjectCode,
                    TransactionCompleted = obj.TransactionCompleted,
                    TaskDate = obj.TaskDate,
                    TimeIn = obj.TimeIn,
                    TimeOut = obj.TimeOut,
                };

                string _strresult = string.Empty;

                bool _boolResult = _clsTaskBLL.SaveUpdate_Task(_objEntity, out _strresult);

                ViewBag.Success = _boolResult;
                ViewBag.Message = _strresult;

                return Content(_strresult);
            }

            return View();
        }

        #endregion

        #region - Task Allocation

        public ActionResult IndexAllocation()
        {
            return View();
        }

        public JsonResult Get_TaskAllocationList()
        {
            List<clsEntity_Master_Task> list = _clsTaskBLL.Get_TaskAllocationList("");
            return Json(new { aaData = list }, JsonRequestBehavior.AllowGet);
        }

        //[Authorize]
        [HttpGet]
        public ActionResult TaskAllocation(string taskAllocationID)
        {
            ViewBag.CustomerList = GetCustomerList();
            ViewBag.ProjectList = GetProjectList();
            ViewBag.ActivityList = GetActivityList();

            if (string.IsNullOrEmpty(taskAllocationID) == false)
            {
                var obj = _clsTaskBLL.Get_TaskAllocationList(taskAllocationID);
                if (obj.Count > 0)
                {
                    var _model = new TaskModel
                    {
                        TaskAllocationID = obj[0].TaskAllocationID,
                        CustomerCode = obj[0].CustomerCode,
                        ActivityCode = obj[0].ActivityCode,
                        ProjectCode = obj[0].ProjectCode,
                        HourlyTarget = obj[0].HourlyTarget,
                        DailyTarget = obj[0].DailyTarget,
                    };

                    return View(_model);
                }
            }

            return View();
        }

        // Post Data
        //[Authorize]
        [HttpPost]
        public ActionResult TaskAllocation(TaskModel obj)
        {
            if (ModelState.IsValid)
            {
                clsEntity_Master_Task _objEntity = new clsEntity_Master_Task()
                {
                    TaskAllocationID = obj.TaskAllocationID,
                    CustomerCode = obj.CustomerCode,
                    ActivityCode = obj.ActivityCode,
                    ProjectCode = obj.ProjectCode,
                    HourlyTarget = obj.HourlyTarget,
                    DailyTarget = obj.DailyTarget,
                };

                string _strresult = string.Empty;

                bool _boolResult = _clsTaskBLL.SaveUpdate_TaskAllocation(_objEntity, out _strresult);

                ViewBag.Success = _boolResult;
                ViewBag.Message = _strresult;

                return Content(_strresult);
            }

            return View();
        }



        #endregion


        [NonAction]
        private SelectList GetEmployeeList()
        {
            clsEmployeeBLL _clsEmployeeBLL = new clsEmployeeBLL();
            return new SelectList(_clsEmployeeBLL.Get_EmployeeList(), "EmployeeCode", "EmployeeName");
        }

        [NonAction]
        private SelectList GetProjectList()
        {
            clsProjectBLL _clsProjectBLL = new clsProjectBLL();
            return new SelectList(_clsProjectBLL.Get_ProjectList(), "ProjectCode", "ProjectName");
        }

        [NonAction]
        private SelectList GetActivityList()
        {
            clsActivityBLL _clsActivityBLL = new clsActivityBLL();
            return new SelectList(_clsActivityBLL.Get_ActivityList(), "ActivityCode", "ActivityName");
        }

        [NonAction]
        private SelectList GetCustomerList()
        {
            clsCustomerBLL _clsCustomerBLL = new clsCustomerBLL();
            return new SelectList(_clsCustomerBLL.Get_CustomerMaster(""), "CustomerCode", "CustomerName");
        }


    }
}
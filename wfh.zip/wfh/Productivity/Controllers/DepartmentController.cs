﻿using Productivity.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Productivity_BO;
using Productivity_BLL;

namespace Productivity.Controllers
{
    public class DepartmentController : Controller
    {
        clsDepartmentBLL _clsDepartmentBLL = null;

        public DepartmentController()
        {
            _clsDepartmentBLL = new clsDepartmentBLL();
        }

        // GET: Department
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult Get_DepartmentMaster()
        {
            List<clsEntity_Master_Department> list = _clsDepartmentBLL.Get_DepartmentMaster("");
            return Json(new { aaData = list }, JsonRequestBehavior.AllowGet);
        }

        //[Authorize]
        [HttpGet]
        public ActionResult Department(string DepartmentCode)
        { 
            if (string.IsNullOrEmpty(DepartmentCode) == false)
            {
                List<clsEntity_Master_Department> obj = _clsDepartmentBLL.Get_DepartmentMaster(DepartmentCode);
                
                var _model = new DepartmentModel
                {
                    DepartmentCode = obj[0].DepartmentCode,
                    DepartmentName = obj[0].DepartmentName,
                };

                return View(_model);
            }
            return View();
        }

        // Post Data
        //[Authorize]
        [HttpPost]
        public ActionResult Department(DepartmentModel obj)
        {
            if (ModelState.IsValid)
            {
                // Add Values in Entity
                clsEntity_Master_Department _objEntity = new clsEntity_Master_Department()
                {
                    DepartmentCode = obj.DepartmentCode,
                    DepartmentName = obj.DepartmentName,
                };

                string _strresult = string.Empty;
                
                bool _boolResult = _clsDepartmentBLL.SaveUpdate_DepartmentMaster(_objEntity, out _strresult);

                ViewBag.Success = _boolResult;
                ViewBag.Message = _strresult;

                return Content(_strresult);
            }
           
            return View();
        }

        // Delete
        [HttpPost]
        public void DeleteDepartment(string departmentCode)
        {
            _clsDepartmentBLL.DeleteDepartment(departmentCode);
        }

    }
}
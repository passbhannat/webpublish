import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guest-footer',
  templateUrl: './guest-footer.component.html',
  styleUrls: ['./guest-footer.component.scss']
})
export class GuestFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
